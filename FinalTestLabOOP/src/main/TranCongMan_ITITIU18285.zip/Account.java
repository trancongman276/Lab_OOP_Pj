package main;

public abstract class Account {
	protected String accountID, customerID, accountType;
	protected double balance;
	
	public abstract boolean withdraw(double amount);
	
	public String toString() {
		return "accID: "+accountID+"; "+accountType+"; current balance: "+balance;
	}
	
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}
